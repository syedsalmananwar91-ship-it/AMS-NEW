import { getStore } from '@netlify/blobs';
import { getUser } from '@netlify/identity';
import type { Context } from '@netlify/functions';

export default async (request: Request, context: Context) => {
  const slot = (context.params.slot ?? '').replace(/\.mp4$/, '');
  if (!['menswear', 'fabric-detail', 'womenswear'].includes(slot)) return new Response('Not found', { status: 404 });
  const store = getStore({ name: 'fashion-videos', consistency: 'strong' });
  const key = `${slot}.mp4`;
  if (request.method === 'PUT' || request.method === 'DELETE') {
    if (request.headers.get('origin') !== new URL(request.url).origin) return new Response('Forbidden', { status: 403 });
    const user = await getUser();
    if (!user?.roles?.includes('admin')) return new Response('Administrator access required', { status: 403 });
    if (request.method === 'DELETE') {
      await store.delete(key);
      return new Response(null, { status: 204 });
    }
    if (request.headers.get('content-type')?.split(';')[0] !== 'video/mp4') return new Response('Upload an MP4 video.', { status: 415 });
    if (Number(request.headers.get('content-length')) > 4 * 1024 * 1024) return new Response('Video must be 4 MB or smaller.', { status: 413 });
    const data = await request.arrayBuffer();
    if (data.byteLength < 24 || data.byteLength > 4 * 1024 * 1024) return new Response('Video must be between 24 bytes and 4 MB.', { status: 413 });
    if (new TextDecoder().decode(data.slice(4, 8)) !== 'ftyp') return new Response('The file is not a valid MP4.', { status: 415 });
    await store.set(key, data);
    return Response.json({ saved: true });
  }
  if (!['GET', 'HEAD'].includes(request.method)) return new Response('Method not allowed', { status: 405, headers: { Allow: 'GET, HEAD, PUT, DELETE' } });
  const data = await store.get(key, { type: 'arrayBuffer' });
  if (!data) {
    // Default footage stays on the CDN; no proxying or third-party dependency.
    return Response.redirect(new URL(`/assets/videos/${slot}.mp4`, request.url), 302);
  }
  const size = data.byteLength;
  const headers: Record<string, string> = { 'Content-Type': 'video/mp4', 'Accept-Ranges': 'bytes', 'Cache-Control': 'no-cache', 'X-Content-Type-Options': 'nosniff' };
  const range = request.headers.get('range');
  if (range) {
    const match = /^bytes=(\d*)-(\d*)$/.exec(range);
    if (!match || (!match[1] && !match[2])) return new Response(null, { status: 416, headers: { 'Content-Range': `bytes */${size}` } });
    const start = match[1] ? Number(match[1]) : Math.max(0, size - Number(match[2]));
    const end = match[1] && match[2] ? Math.min(Number(match[2]), size - 1) : size - 1;
    if (start >= size || end < start) return new Response(null, { status: 416, headers: { 'Content-Range': `bytes */${size}` } });
    headers['Content-Range'] = `bytes ${start}-${end}/${size}`;
    headers['Content-Length'] = String(end - start + 1);
    return new Response(request.method === 'HEAD' ? null : data.slice(start, end + 1), { status: 206, headers });
  }
  headers['Content-Length'] = String(size);
  return new Response(request.method === 'HEAD' ? null : data, { headers });
};
export const config = { path: '/api/gallery-video/:slot' };

import { getUser, login, logout, acceptInvite, recoverPassword, requestPasswordRecovery, refreshSession } from '@netlify/identity';
export default async (request: Request) => {
  const headers = { 'Cache-Control': 'no-store' };
  if (request.method === 'GET') {
    await refreshSession();
    const user = await getUser();
    return Response.json({ admin: Boolean(user?.roles?.includes('admin')), signedIn: Boolean(user) }, { headers });
  }
  if (request.method !== 'POST') return new Response('Method not allowed', { status: 405 });
  if (request.headers.get('origin') !== new URL(request.url).origin) return new Response('Forbidden', { status: 403 });
  try {
    const body = await request.json();
    if (body.action === 'logout') await logout();
    else if (body.action === 'invite') await acceptInvite(body.token, body.password);
    else if (body.action === 'recovery') await recoverPassword(body.token, body.password);
    else if (body.action === 'forgot') await requestPasswordRecovery(body.email);
    else if (body.action === 'login') await login(body.email, body.password);
    else return new Response('Unknown action', { status: 400 });
    return Response.json({ ok: true }, { headers });
  } catch {
    return Response.json({ error: 'Unable to sign in or update your account. Check your details or request a new invitation.' }, { status: 400, headers });
  }
};
export const config = { path: '/api/admin-session' };

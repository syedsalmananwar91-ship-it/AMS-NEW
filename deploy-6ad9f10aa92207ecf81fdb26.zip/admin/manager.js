const access=document.querySelector('#access');
const workspace=document.querySelector('#workspace');
const status=document.querySelector('#access-status');
const form=document.querySelector('#sign-in');
const params=new URLSearchParams(location.hash.slice(1));
const invite=params.get('invite_token');
const recovery=params.get('recovery_token');
// Invitation and recovery fragments stay out of history and request URLs.
if(invite||recovery)history.replaceState(null,'',location.pathname);
if(invite||recovery){
 document.querySelector('#access-title').textContent=invite?'Set your password':'Choose a new password';
 document.querySelector('#email-label').hidden=true;
 document.querySelector('#email').required=false;
 document.querySelector('#password').autocomplete='new-password';
 document.querySelector('#submit').textContent='Save password';
 document.querySelector('#forgot').hidden=true;
}
async function session(body){
 const response=await fetch('/api/admin-session',body?{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)}:{});
 const data=await response.json();
 if(!response.ok)throw new Error(data.error||'Unable to connect. Please try again.');
 return data;
}
async function check(){
 const data=await session();
 const show=data.admin&&!invite&&!recovery;
 access.hidden=show;workspace.hidden=!show;
 if(data.signedIn&&!data.admin)status.textContent='Your account is signed in but needs the admin role. Assign that role in the Netlify Identity dashboard, then sign in again.';
 if(show&&!document.querySelector('.card'))renderCards();
}
form.addEventListener('submit',async event=>{
 event.preventDefault();const button=document.querySelector('#submit');button.disabled=true;status.textContent='Connecting…';
 try{
  await session({action:invite?'invite':recovery?'recovery':'login',email:document.querySelector('#email').value,password:document.querySelector('#password').value,token:invite||recovery});
  location.replace('/admin/login/');
 }catch(error){status.textContent=error.message;button.disabled=false;}
});
document.querySelector('#forgot').addEventListener('click',async()=>{
 const email=document.querySelector('#email');if(!email.reportValidity())return;
 try{await session({action:'forgot',email:email.value});status.textContent='Check your inbox for a password reset link.';}catch(error){status.textContent=error.message;}
});
document.querySelector('#sign-out').addEventListener('click',async()=>{try{await session({action:'logout'});location.reload();}catch(error){status.textContent=error.message;access.hidden=false;}});
function renderCards(){
 for(const [slot,label] of [['menswear','Menswear'],['fabric-detail','Fabric & craftsmanship'],['womenswear','Womenswear']]){
  const card=document.createElement('article');card.className='card';
  card.innerHTML=`<h3>${label}</h3><video controls muted playsinline preload="metadata" src="/api/gallery-video/${slot}.mp4"></video><label for="file-${slot}">Choose your video<input id="file-${slot}" type="file" accept="video/mp4,.mp4"></label><small>MP4 · up to 4 MB · portrait recommended</small><button class="publish" disabled>Publish video ↗</button><button class="restore secondary">Use stock video</button><p role="status" aria-live="polite"></p>`;
  document.querySelector('#cards').append(card);
  const preview=card.querySelector('video'),file=card.querySelector('input'),publish=card.querySelector('.publish'),restore=card.querySelector('.restore'),message=card.querySelector('[role=status]');
  let objectURL=null,selected=null,checking=false;
  const saved=()=>`/api/gallery-video/${slot}.mp4?v=${Date.now()}`;
  const clear=()=>{if(objectURL){URL.revokeObjectURL(objectURL);objectURL=null;}selected=null;file.value='';publish.disabled=true;};
  file.addEventListener('change',()=>{
   clearPreview();selected=file.files[0];publish.disabled=true;
   if(!selected)return;
   if(!/\.mp4$/i.test(selected.name)||selected.size>4*1024*1024){message.textContent='Choose an MP4 video no larger than 4 MB.';selected=null;return;}
   checking=true;objectURL=URL.createObjectURL(selected);preview.src=objectURL;preview.load();message.textContent='Checking video…';
  });
  function clearPreview(){if(objectURL){URL.revokeObjectURL(objectURL);objectURL=null;}checking=false;}
  preview.addEventListener('loadeddata',()=>{if(checking){checking=false;publish.disabled=false;message.textContent='Ready to preview. Press play to check the motion, then publish.';}});
  preview.addEventListener('error',()=>{if(checking){checking=false;selected=null;publish.disabled=true;message.textContent='This video cannot play in your browser. Export it as H.264 MP4 and try again.';}});
  async function save(method){
   if(method==='PUT'&&!selected)return;
   publish.disabled=true;restore.disabled=true;file.disabled=true;message.textContent=method==='PUT'?'Uploading and publishing…':'Restoring stock video…';
   try{
    await session();
    const response=await fetch(`/api/gallery-video/${slot}.mp4`,{method,headers:method==='PUT'?{'Content-Type':'video/mp4'}:{},body:method==='PUT'?selected:undefined});
    if(!response.ok)throw new Error(await response.text());
    clear();preview.src=saved();preview.load();message.textContent=method==='PUT'?'Published. Your video is now live in the gallery.':'Stock video restored.';
   }catch(error){message.textContent=error.message;publish.disabled=!selected;}
   finally{restore.disabled=false;file.disabled=false;}
  }
  publish.addEventListener('click',()=>save('PUT'));restore.addEventListener('click',()=>save('DELETE'));
 }
}
check().catch(()=>{status.textContent='Video manager is unavailable. Please try again after the site has finished deploying.';});

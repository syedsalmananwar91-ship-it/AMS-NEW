# Gallery footage

The three local clips are excerpts of real stock footage downloaded from Pexels under the [Pexels License](https://www.pexels.com/license/). They were resized to 720 × 1280, muted, and given a short dissolve at the loop boundary. No artificial frames were used to simulate movement.

- Menswear: [Man posing on a staircase](https://www.pexels.com/video/man-posing-on-a-staircase-5561960/), video 5561960.
- Fabric and craftsmanship: [Close-up video of a sewing machine](https://www.pexels.com/video/close-up-video-of-a-sewing-machine-5758549/), video 5758549.
- Womenswear: [A woman leaning on a wall](https://www.pexels.com/video/a-woman-leaning-on-a-wall-8738298/), video 8738298.

## Upload your own videos

Open **Admin** in the website navigation, or visit `/admin/login/`. For the first administrator, invite your email in the site's Netlify Identity dashboard and assign the `admin` role. Invitation links open the password setup screen. Subsequent visits use email and password.

Choose an MP4 for a gallery panel, preview it, and select **Publish video**. Uploads are saved in Netlify Blobs and replace that panel for all visitors without a redeploy. **Use stock video** removes the uploaded file and restores the bundled clip.

Use a short, portrait H.264 MP4, at most 4 MB, with fast-start/web-optimized metadata. Export at 720 × 1280 and the original 24–30 fps. Uploads are not transcoded. The size limit keeps uploads within the serverless request limit and limits gallery bandwidth. Longer videos should be trimmed and compressed before uploading.

Alternatively, replace the relevant MP4 and matching JPG poster in this directory and redeploy. Remove any published override in the video manager to use that bundled replacement.
